# Partner Program MVP

Полноценная партнерская система для контент-мейкеров с поддержкой:
- YouTube и TikTok видео
- Учётом просмотров
- Выплатами в USDT (TRC20)
- Панелью админа и мейкера

## 📦 Структура
- `backend/` — Node.js + Express + PostgreSQL
- `frontend/` — React + Vite SPA
- `database/init.sql` — SQL-скрипт создания таблиц

## 🚀 Быстрый старт (локально)
1. `cd backend && npm install && npm start`
2. `cd frontend && npm install && npm run dev`
3. Настрой `.env` в `backend/`

## 🌍 Railway деплой
1. `railway init`
2. `railway add plugin postgresql`
3. Добавь `.env` с `DATABASE_URL`, `JWT_SECRET`
4. `railway up`

## 📬 Контакты
Разработано с помощью ChatGPT 😉